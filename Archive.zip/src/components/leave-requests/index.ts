// src/components/leave-requests/index.ts

// This directory is for leave request components
// Currently using simplified implementation in pages directly