// src/components/academic/index.ts
export * from './academic-structure-manager';
export * from './academic-year-manager';
export * from './academic-year-setup-wizard';
export * from './add-section-form';
export * from './comprehensive-academic-manager';
export * from './conflict-detection';
export * from './historical-structure-view';
export * from './academic-structure-stats';
export * from './subject-teacher-assignment';
export * from './teacher-assignment';
export * from './SubjectManager';