// src/app/(admin)/staff/assign-subjects/layout.tsx

export default function AssignSubjectsLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
