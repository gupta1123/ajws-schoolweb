// src/app/calendar/pending/layout.tsx

export default function PendingEventsLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
