export default function EditAnnouncementLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
