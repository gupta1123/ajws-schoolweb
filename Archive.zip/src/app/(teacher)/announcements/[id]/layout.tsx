export default function AnnouncementViewLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
