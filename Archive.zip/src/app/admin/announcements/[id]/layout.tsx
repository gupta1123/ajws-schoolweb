// src/app/admin/announcements/[id]/layout.tsx

export default function AdminAnnouncementDetailLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
}
