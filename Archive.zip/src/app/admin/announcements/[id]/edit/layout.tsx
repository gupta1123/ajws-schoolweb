// src/app/admin/announcements/[id]/edit/layout.tsx

export default function AdminEditAnnouncementLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
}
