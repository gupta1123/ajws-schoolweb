// src/app/admin/announcements/create/layout.tsx

export default function AdminCreateAnnouncementLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
}
